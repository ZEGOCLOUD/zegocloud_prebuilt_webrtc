import React from "react";
import { ZegoCloudRTCCore } from "../../../../modules";
export declare class ZegoRoomInvite extends React.Component<{
    core: ZegoCloudRTCCore;
    closeCallBack: () => void;
}> {
    render(): React.ReactNode;
}
