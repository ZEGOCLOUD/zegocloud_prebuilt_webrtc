import React from "react";
export declare class ZegoLoading extends React.Component<{
    content: string;
}> {
    render(): React.ReactNode;
}
